
# Pico‑ICE Labs — Beginner → Professional

This package contains **separate, self‑contained labs** for the Pico‑ICE (RP2040 + Lattice iCE40UP5K) development board. Each lab includes:
- Objectives, prerequisites, estimated time
- Step‑by‑step tasks, validation checks, troubleshooting
- Starter templates (FPGA/MCU/Host) where applicable

See `INSTALL-macos.md` and `INSTALL-windows.md` for toolchain setup.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
