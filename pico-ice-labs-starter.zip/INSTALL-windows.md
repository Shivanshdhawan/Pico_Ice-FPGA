
# Install — Windows 10/11

## FPGA Toolchain
- Install **OSS CAD Suite** or **Tabby CAD** (includes Yosys/nextpnr/IcePack). Start their shell to build.
- Install **dfu-util** (often included in Tabby/OSS CAD environment).
- Use **Zadig** to set **libusbK** driver for the "iCE40 DFU (CRAM)" interface if DFU is not detected.

## MCU Toolchain (RP2040)
- Install **CMake**, **Ninja**, **arm-none-eabi-gcc** (ARM GNU toolchain), and clone **pico-sdk**.

## Optional
- VS Code, Python 3 (`pip install pyserial`)


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
