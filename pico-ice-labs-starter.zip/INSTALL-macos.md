
# Install — macOS (Apple Silicon or Intel)

## FPGA Toolchain
```bash
brew install yosys nextpnr-ice40 dfu-util
# Or use OSS CAD Suite builds: https://github.com/YosysHQ/oss-cad-suite-build
```
## MCU Toolchain (RP2040)
```bash
brew install cmake ninja arm-none-eabi-gcc
```
## Optional
- VS Code, Python 3 (`pip install pyserial`)


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
