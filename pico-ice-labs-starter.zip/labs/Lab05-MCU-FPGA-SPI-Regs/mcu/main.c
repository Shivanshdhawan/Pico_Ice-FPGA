
#include "pico/stdlib.h"
#include "ice_fpga.h"
#include "ice_spi.h"

static uint8_t rd(uint8_t a){ uint8_t b[2]={(uint8_t)(a|0x80),0}; ice_spi_xfer(b,2); return b[1]; }
static void    wr(uint8_t a,uint8_t v){ uint8_t b[2]={(uint8_t)(a&0x7F),v}; ice_spi_xfer(b,2); }

int main(){
  stdio_init_all();
  ice_fpga_init(12); // MHz; match FPGA design
  bool ok = ice_fpga_start(); if(!ok) while(1) tight_loop_contents();
  for(int i=0;i<6;i++){ wr(0x01,(i&1)?1:0); sleep_ms(200);} // LED
  while(1){ uint8_t lo=rd(0x02), hi=rd(0x03); (void)lo; (void)hi; sleep_ms(50);} 
}
