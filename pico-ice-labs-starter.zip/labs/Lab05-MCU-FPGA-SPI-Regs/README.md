# MCU↔FPGA SPI Register Map


**Objective.** Implement/read/write a 4‑register SPI map between MCU and FPGA.
**Steps.** Build FPGA (`make`) and MCU (`cmake .. && make`), then run `host/cdc_spi_demo.py` to poke registers.
**Validate.** LED register works; counter reads increment.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
