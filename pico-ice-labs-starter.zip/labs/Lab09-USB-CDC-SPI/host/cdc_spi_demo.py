
import serial, time, sys
PORT = sys.argv[1] if len(sys.argv)>1 else '/dev/ttyACM0'
BAUD = 115200

def select_fpga(ser): ser.write(bytes([0x80,0x00]))
def spi_wr2(ser,a,v): ser.write(bytes([0x05, a & 0x7F, v, 0x00]))
def spi_rd2(ser,a):
    ser.write(bytes([0x05, (a|0x80), 0x00, 0x00])); time.sleep(0.01)
    ser.write(bytes([0x82]))
    return ser.read(2)

with serial.Serial(PORT, BAUD, timeout=0.3) as ser:
    time.sleep(0.2)
    select_fpga(ser)
    spi_wr2(ser,0x01,0x01); time.sleep(0.2)
    spi_wr2(ser,0x01,0x00)
    lo = spi_rd2(ser,0x02)[-1]
    hi = spi_rd2(ser,0x03)[-1]
    print('Counter:', (hi<<8)|lo)
