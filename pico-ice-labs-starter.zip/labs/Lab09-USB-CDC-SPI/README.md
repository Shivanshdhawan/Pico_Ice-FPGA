# USB CDC–SPI Host Bridge


**Objective.** Drive the SPI fabric from a PC over USB CDC using the SDK USB‑SPI example.
**Steps.** Build the SDK USB‑SPI example and run `host/cdc_spi_demo.py /dev/ttyACM0`.
**Validate.** SPI reads/writes match analyzer traces.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
