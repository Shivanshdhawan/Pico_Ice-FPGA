
from machine import Pin
import ice
fpga = ice.fpga(cdone=Pin(26), clock=Pin(24), creset=Pin(27),
                cram_cs=Pin(9), cram_mosi=Pin(8), cram_sck=Pin(10),
                frequency=12)
with open('top.bin','br') as f:
    fpga.start(); fpga.cram(f)
