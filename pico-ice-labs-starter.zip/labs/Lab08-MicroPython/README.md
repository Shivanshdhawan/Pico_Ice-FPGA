# MicroPython Fast Path


**Objective.** Program the FPGA from MicroPython for ultra‑fast demos.
**Steps.** Flash a MicroPython UF2 build; copy `top.bin` and run `micropython_fpga_load.py` in REPL.
**Validate.** Design runs; adjust `frequency` to match your clocking.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
