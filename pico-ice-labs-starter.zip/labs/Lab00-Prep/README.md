# Prep & Installation


**Objective.** Install toolchains, clone repos, verify USB/DFU/MSC.
**Estimated time.** 20–40 min
**Steps.**
1) Install tools (see root INSTALL docs).
2) Clone repos:
   ```bash
   git clone https://github.com/tinyvision-ai-inc/pico-ice
   git clone https://github.com/tinyvision-ai-inc/pico-ice-sdk
   ```
3) Connect the board and enumerate serial/DFU.
**Validate.** You can see CDC ports and dfu-util lists the device.
**Troubleshooting.** On Windows, use Zadig to set libusbK for DFU.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
