# RP2040 Baseline Firmware (SDK Example)


**Objective.** Build/flash a minimal RP2040 firmware with pico‑ice‑sdk linked.
**Steps.** Add `pico-sdk` and `pico-ice-sdk` as submodules; `cmake -DPICO_BOARD=pico_ice .. && make`.
**Validate.** UF2 flashes; CDC enumerates.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
