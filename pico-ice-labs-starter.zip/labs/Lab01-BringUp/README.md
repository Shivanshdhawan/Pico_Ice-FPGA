# Board Bring-Up & Default Firmware


**Objective.** Learn BOOTSEL/MSC/DFU; update RP2040 firmware.
**Steps.** Enter BOOTSEL (BT→GND + RESET) → `RPI-RP2` appears → drag a `.uf2`.
**Validate.** Board reboots; CDC ports show.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
