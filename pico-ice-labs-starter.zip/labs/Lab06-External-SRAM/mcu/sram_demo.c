// TODO: use ice_sram.h from SDK to stream blocks in/out of SRAM.
