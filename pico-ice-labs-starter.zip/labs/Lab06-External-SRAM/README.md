# External qSPI SRAM Buffering


**Objective.** Use 8 MB qSPI SRAM as a streaming buffer.
**Steps.** Review `include/ice_sram.h` and `examples/` in SDK; write bursts from MCU, read/process from FPGA.
**Validate.** Host round‑trip check passes; throughput measured.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
