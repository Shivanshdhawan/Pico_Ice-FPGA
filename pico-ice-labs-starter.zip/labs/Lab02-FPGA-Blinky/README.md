# FPGA Hello World (Blink)


**Objective.** Build and program a blinking LED bitstream.
**Steps.**
1) Edit `constraints/pico_ice_example.pcf` with real pins from the board repo.
2) `make` → produces `build/top.bin`.
3) `dfu-util --alt 1 --download build/top.bin` (CRAM) or convert to UF2 for MSC.
**Validate.** LED blinks.
**Troubleshooting.** If DFU not found on Windows, install libusbK via Zadig.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
