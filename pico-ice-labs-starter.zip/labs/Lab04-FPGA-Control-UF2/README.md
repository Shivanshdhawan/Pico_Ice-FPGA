# MCU-driven FPGA Control (Clock/Reset + UF2 Flash)


**Objective.** Drive FPGA clock/reset and learn UF2 programming.
**Steps.** Build MCU app; convert BIN→UF2 with microsoft/uf2 and drag to MSC mode.
**Validate.** FPGA CDONE goes high; LED register toggles via MCU.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
