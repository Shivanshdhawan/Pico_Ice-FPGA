# Capstone: Mini Hardware Accelerator


**Objective.** Build a streaming FIR/Sobel accelerator with MCU orchestration and benchmarks.
**Steps.** Define I/O protocol (SPI or SRAM ring), implement RTL, integrate MCU host, and benchmark vs. pure MCU.
**Deliverables.** RTL + tests, MCU app, host benchmarks (plots).


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
