# PMOD Expansion (Sensor In, Real-Time Processing)


**Objective.** Attach a PMOD sensor and process data in real time.
**Steps.** Wire a PMOD to FPGA PMOD header; define pins (PCF) and implement SPI/I²C interface (or start with RP2040 PIO then migrate).
**Validate.** Live plots on host; deterministic pre‑processing in FPGA.


**GitHub References**
- Board repo (schematics/RTL/docs): https://github.com/tinyvision-ai-inc/pico-ice
- SDK repo (headers, examples): https://github.com/tinyvision-ai-inc/pico-ice-sdk
- MicroPython builds: https://github.com/tinyvision-ai-inc/pico-ice-micropython/releases
- Microsoft UF2 tool: https://github.com/microsoft/uf2
